package com.ssafy.board;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

@WebServlet("/register")
public class ArticleWrite extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
	public void init() throws ServletException {
		super.init();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("드라이버 로딩 성공");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		  1. data get : 사용자 아이디, 제목, 내용
		String userId = request.getParameter("userid");
		String subject = request.getParameter("subject");
		String content = request.getParameter("content");
//		  2. logic : 1의 data를 db에 insert
		int cnt = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = this.getConnection();
			String sql = "insert into board (user_id, subject, content) \n";
			sql += "values (?, ?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			pstmt.setString(2, subject);
			pstmt.setString(3, content);
			cnt = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null)
					pstmt.close();
				if(conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
//		  3. create page(html)
		 PrintWriter out = response.getWriter();
		 out.println("<!DOCTYPE html>");
		 out.println("<html lang=\"ko\">");
		 out.println("  <head>");
		 out.println("    <meta charset=\"UTF-8\" />");
		 out.println("    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" />");
		 out.println("    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />");
		 out.println("    <link");
		 out.println("      href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css\"");
		 out.println("      rel=\"stylesheet\"");
		 out.println("      integrity=\"sha384-LN+7fdVzj6u52u30Kp6M/trliBMCMKTyK833zpbD+pXdCLuTusPj697FH4R/5mcr\"");
		 out.println("      crossorigin=\"anonymous\"");
		 out.println("    />");
		 out.println("    <link href=\"../assets/css/app.css\" rel=\"stylesheet\" />");
		 out.println("    <title>HISSAM</title>");
		 out.println("  </head>");
		 out.println("  <body>");
		 out.println("    <div class=\"container\">");
		 out.println("      <div class=\"row justify-content-center\">");
		 out.println("        <div class=\"col-lg-8 col-md-10 col-sm-12\">");
		 out.println("          <h2 class=\"my-3 py-3 shadow-sm bg-light text-center\">");
		 out.println("            <mark class=\"sky\">글쓰기 결과</mark>");
		 out.println("          </h2>");
		 out.println("        </div>");
		 out.println("        <div class=\"col-lg-8 col-md-10 col-sm-12\">");
		 if(cnt == 1) {
			 out.println("          <div class=\"card text-center bg-light\">");
			 out.println("            <h2 class=\"fw-bold text-primary pt-3\">등록 완료!!!</h2>");
			 out.println("            <div class=\"card-body\">");
			 out.println("              <p class=\"card-text\">글작성이 완료되었습니다.</p>");
			 out.println("              <button type=\"button\" id=\"btn-list\" class=\"btn btn-outline-primary\">");
			 out.println("                글목록 페이지 이동...");
			 out.println("              </button>");
			 out.println("            </div>");
			 out.println("          </div>");
		 }else {
			 out.println("          <div class=\"card text-center bg-light\">");
			 out.println("            <h2 class=\"fw-bold text-danger pt-3\">등록 실패T.T</h2>");
			 out.println("            <div class=\"card-body\">");
			 out.println("              <p class=\"card-text\">");
			 out.println("                글작성에 문제가 있습니다. <br />");
			 out.println("                잠시 후 시도해주세요.");
			 out.println("              </p>");
			 out.println("              <button type=\"button\" id=\"btn-list\" class=\"btn btn-outline-danger\">");
			 out.println("                글목록 페이지 이동...");
			 out.println("              </button>");
			 out.println("            </div>");
			 out.println("          </div>");
		 }
		 out.println("        </div>");
		 out.println("      </div>");
		 out.println("    </div>");
		 out.println("    <script");
		 out.println("      src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js\"");
		 out.println("      integrity=\"sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q\"");
		 out.println("      crossorigin=\"anonymous\"");
		 out.println("    ></script>");
		 out.println("    <script>");
		 out.println("      document.querySelector(\"#btn-list\").addEventListener(\"click\", function () {");
		 out.println("        location.href = \"\";");
		 out.println("      });");
		 out.println("    </script>");
		 out.println("  </body>");
		 out.println("</html>");

		 
		//doGet(request, response);
	}
	

	private Connection getConnection() throws SQLException {
		return DriverManager.getConnection("jdbc:mysql://localhost:3306/backend", "ssafy", "ssafy");
	}

}
